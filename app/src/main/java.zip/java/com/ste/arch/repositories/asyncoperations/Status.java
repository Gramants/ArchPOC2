package com.ste.arch.repositories.asyncoperations;


public enum Status {
    SUCCESS,
    ERROR,
    LOADING
}