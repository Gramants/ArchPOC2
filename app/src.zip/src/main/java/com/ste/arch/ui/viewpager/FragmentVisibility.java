package com.ste.arch.ui.viewpager;



public interface FragmentVisibility {
    void fragmentBecameVisible();
}
