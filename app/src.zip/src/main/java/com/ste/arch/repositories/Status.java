package com.ste.arch.repositories;


public enum Status {
    SUCCESS,
    ERROR,
    SUCCESSFROMDB,
    SUCCESSFROMUI,
    LOADING
}