package com.ste.arch.repositories.api.checknetwork;


public interface CheckNetwork {
    Boolean isConnectedToInternet();
}
